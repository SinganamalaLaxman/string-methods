import logo from './logo.svg';
import './App.css';
//strings are immutable.


//let name = "lakshman"//we can write outside the function,loops,conditional statements.but it is not remomended.
function App() {

  let todayNews = "CBN & Pawan Oath As CM & Deputy CM"
  let firstName = "Lakshman "
  let lastName = "Singanamala"
 
  return (
    <div className="App">
    <h1>Learning String Methods</h1>
    <button onClick = {()=>{
      let lengthOfTheNews = todayNews.length;

      console.log(lengthOfTheNews);
    }}>Length</button>
    <button onClick = {()=>{
      let upper = todayNews.toUpperCase();
      console.log(upper);
    }}>Upper Letters</button>
    <button onClick = {()=>{
      let lower = todayNews.toLowerCase();
      console.log(lower);
    }}>Lower Letters</button>
    <button onClick ={()=>{
      let fullName = firstName.concat(lastName);
      console.log(fullName);
    }}>Concat</button>
    <button onClick = {()=>{
      let message = "  Lakshman Sinagnamala    "
      console.log(message.trimStart());
      console.log(message.trimEnd());
      console.log(message.trim());
    }}>Trim/TrimStart/TrimEnd</button>
    <button onClick = {()=>{
      let str = "oh my god";
      let startPad = str.padStart(100,"0");
      let endPad = str.padEnd(25,"!");
      console.log(startPad);
      console.log(endPad);
    }}>Pad Start/Pad End</button>
    <button onClick = {()=>{
      let ram = "Jai Sri Ram"
      let counteOfRam = ram.repeat(101);
      console.log(counteOfRam);
    }}>Repeat</button>
    <button onClick = {()=>{
      let electionsOver = `India Has conducted elections.India completed their elctions procedure by june 4th.India has 60cr plus voters.`
      console.log(electionsOver.replace("India","Bharath"));
      console.log(electionsOver.replaceAll("India","Bharath"));
      
    }}>Replace/Replace All</button>
    <button onClick = {()=>{
      let msg = "India Is My Country & All Indains are my brothers & sisters"
      let msg1 = "               hutty               "
      console.log(msg);
      console.log(msg.split("India"));
      console.log(msg1);
      console.log(msg1.split(" "));
    }}>Split</button>
    <button onClick = {()=>{
      let text = "Ramudu";
      console.log(text.slice(0,3));
      console.log(text.substring(0,3));
      console.log(text.substr(0,3));
    }}>Slice/Sub String/sub str</button>

    </div>
  );
}

export default App;
